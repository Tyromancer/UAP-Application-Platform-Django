from django.shortcuts import render
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.forms.models import modelform_factory
from ckeditor.widgets import CKEditorWidget
from .forms import URPCreateForm, URPUpdateForm
from .models import URP
from django.utils import timezone


def home(request):
    ctx = {
        'urps': URP.objects.all(),
    }
    return render(request, 'post/home.html', ctx)


def about(request):
    return render(request, 'post/about.html')


class URPDetailView(DetailView):
    model = URP


class URPCreateView(CreateView):
    model = URP
    template_name = 'post/urp_create.html'
    form_class = URPCreateForm

    def form_valid(self, form):
        print(self.request.user)
        form.instance.posted_by = self.request.user 
        
        return super().form_valid(form)
    # fields = ['title', 'content']

class URPUpdateView(UpdateView):
    model = URP
    template_name = 'post/urp_update.html'
    form_class = URPUpdateForm

    def form_valid(self, form):
        print(self.request.user)
        form.instance.posted_by = self.request.user 
        form.instance.date_posted = str(timezone.now())
        return super().form_valid(form)
    # fields = ['title', 'content']
    

