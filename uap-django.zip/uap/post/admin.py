from django.contrib import admin
from .models import URP, Application


admin.site.register(URP)
admin.site.register(Application)
