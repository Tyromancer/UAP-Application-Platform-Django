from django.urls import path
from . import views
from .views import URPDetailView, URPCreateView, URPUpdateView


urlpatterns = [
    path('', views.home, name='uap-home'),
    # path('^admin/', admin.site.urls),
    path('about/', views.about, name='uap-about'),
    path('urp/<int:pk>', URPDetailView.as_view(), name='urp-detail'),
    path('urp/new/', URPCreateView.as_view(), name='urp-create'),
    path('urp/update/<int:pk>', URPUpdateView.as_view(), name='urp-update'),
]
